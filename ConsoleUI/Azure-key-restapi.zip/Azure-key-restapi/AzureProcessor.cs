﻿using System.Collections.Generic;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text.Json;
using System.Threading.Tasks;
namespace Azure_key_restapi
{
    class AzureProcessor
    {

        const string CLIENTSECRET = "_-IcUrkh6Mz2317-4F_ryDw3_8.VKUJzjg";
        const string CLIENTID = "d0cb4b3d-b227-4d47-b3f9-ce5b9258b037";
        const string BASESECRETURI =
            "https://dev-kv-001.vault.azure.net";

        private static HttpClient client = new HttpClient();

        private static readonly JsonSerializerOptions Options = new JsonSerializerOptions();
        public async Task<string> GetTokenAsync()
        {
            string _token = string.Empty;
            client.DefaultRequestHeaders.Accept.Clear();
            //HttpRequestMessage request = new HttpRequestMessage(HttpMethod.Post);
            client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/x-www-form-urlencoded; charset=UTF-8"));
            // client.DefaultRequestHeaders.
            //client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
            client.DefaultRequestHeaders.Add("grant_type", "client_credentials,");
            client.DefaultRequestHeaders.Add("client_id", "QsiDE2_F~2~6yNwv3u_082xCX5Zr6~~KV-,");
            client.DefaultRequestHeaders.Add("client_secret", "c1e865b6-c86e-4a75-91b0-f28791735c76,");
            client.DefaultRequestHeaders.Add("scope", "https://vault.azure.net/.default");

            var formcontext = new FormUrlEncodedContent(new[]
            {
                new KeyValuePair<string,string>("grant_type", "client_credentials,"),
                new KeyValuePair<string,string>("client_id", "QsiDE2_F~2~6yNwv3u_082xCX5Zr6~~KV-,"),
                new KeyValuePair<string,string>("client_secret", "c1e865b6-c86e-4a75-91b0-f28791735c76,"),
                new KeyValuePair<string,string>("scope", "https://vault.azure.net/.default")
            });
            HttpResponseMessage response = await client.PostAsync("https://login.microsoftonline.com/1f329e8b-f83b-4093-b542-d49338e1ad5f/oauth2/v2.0/token",formcontext);
            TokenResponse token = null;
                           
                token = await Deserialize<TokenResponse>(response);
           

            //client.DefaultRequestHeaders.Add("Authorization-Token", AuthToken);
            //client.DefaultRequestHeaders.Add("ClientID", clientId);

            return token.access_token;
        }

        public async Task<string> GetSecretAsync()
        {
            client = new HttpClient();
            client.DefaultRequestHeaders.Accept.Clear();

            string secretUrl = "https://dev-kv-001.vault.azure.net/secrets/sec2?api-version=2016-10-01";
            string authToken = @"eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiIsIng1dCI6ImtnMkxZczJUMENUaklmajRydDZKSXluZW4zOCIsImtpZCI6ImtnMkxZczJUMENUaklmajRydDZKSXluZW4zOCJ9.eyJhdWQiOiJodHRwczovL3ZhdWx0LmF6dXJlLm5ldCIsImlzcyI6Imh0dHBzOi8vc3RzLndpbmRvd3MubmV0LzFmMzI5ZThiLWY4M2ItNDA5My1iNTQyLWQ0OTMzOGUxYWQ1Zi8iLCJpYXQiOjE2MDYyMDkxMTgsIm5iZiI6MTYwNjIwOTExOCwiZXhwIjoxNjA2MjEzMDE4LCJhaW8iOiJFMlJnWU9DNnZ1YVg3cDBzazdaYzRibW42NmN3QWdBPSIsImFwcGlkIjoiZDBjYjRiM2QtYjIyNy00ZDQ3LWIzZjktY2U1YjkyNThiMDM3IiwiYXBwaWRhY3IiOiIxIiwiaWRwIjoiaHR0cHM6Ly9zdHMud2luZG93cy5uZXQvMWYzMjllOGItZjgzYi00MDkzLWI1NDItZDQ5MzM4ZTFhZDVmLyIsIm9pZCI6ImU1OTcwM2U3LTc1ZmItNDRlYS04ZWU1LWNiYjI5NGI5NTQyOCIsInJoIjoiMC5BQUFBaTU0eUh6djRrMEMxUXRTVE9PR3RYejFMeTlBbnNrZE5zX25PVzVKWXNEZHhBSGMuIiwic3ViIjoiZTU5NzAzZTctNzVmYi00NGVhLThlZTUtY2JiMjk0Yjk1NDI4IiwidGlkIjoiMWYzMjllOGItZjgzYi00MDkzLWI1NDItZDQ5MzM4ZTFhZDVmIiwidXRpIjoiNVYzVmNBSW5wVVN2WFhoWF9UUjRBQSIsInZlciI6IjEuMCJ9.s1oukrTGodTwyBajugoSAFVBMAO3jqCiAX3k07Dw_FiOj370G5EYBxT-vmoYSWjANrLykgt9Y3FPDA6BIGh4Dqr2UDo3qN5UJL-mhMp-EURyaqZ7K_haL7iaErVEpM_gYpOAABj7gTv0LI0keGI28B5RTouPnPpRBhGzHSSB8M-Ms3-Rzn_8WSmzBfSPV5_RpC0TcWr3CdJF4fE4DUmoT0EL1_QbhVadF-7PG8bNsWzouPX1BoriZRf8bqdaSptvX6DB68PvpkVipO46xzMKKvd-zPARJ7xa8PK9-exiq5K3yPLheFhoTbHF5G1zE5sAbIn3YTbsD3S-qg_7V3SeQw";
            client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", authToken);
            client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
            HttpResponseMessage response = client.GetAsync(secretUrl).Result;
            SecretResponse secretResponse = null;
            if (response.IsSuccessStatusCode)
            {
                secretResponse = await Deserialize<SecretResponse>(response); //JsonSerializer.Deserialize<SecretResponse>(jsonResponse);
            }
            System.Console.WriteLine(secretResponse.id);
            return secretResponse.value;
        }
        private static async Task<SecretResponse> Deserialize<SecretResponse>(HttpResponseMessage response)
        {
            var contentStream = await response.Content.ReadAsStreamAsync();
            var result = await JsonSerializer.DeserializeAsync<SecretResponse>(contentStream, Options);
            return result;
        }
    }

    public class TokenResponse
    {
        public string token_type { get; set; }
        public int expires_in { get; set; }
        public int ext_expires_in { get; set; }
        public string access_token { get; set; }
    }


    public class SecretResponse
    {
        public string value { get; set; }
        public string id { get; set; }
        public Attributes attributes { get; set; }
    }

    public class Attributes
    {
        public bool enabled { get; set; }
        public int created { get; set; }
        public int updated { get; set; }
        public string recoveryLevel { get; set; }
    }

}
