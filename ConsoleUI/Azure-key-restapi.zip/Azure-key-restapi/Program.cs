﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Azure_key_restapi
{
    class Program
    {
        static void Main(string[] args)
        {
            AzureProcessor obj = new AzureProcessor();
            obj.GetTokenAsync();
            //Console.WriteLine(obj.GetSecretAsync());
            Console.Read();
        }
    }
}
